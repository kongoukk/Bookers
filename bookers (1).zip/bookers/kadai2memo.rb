<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" media

</head>

<body>
  <p id="notice"></p>
  <h1>Books</h1>
    <table>
     <thead>
       <tr>
        <th>Title</th>
        <th>Body</th>
        <th colspan="3"></th>
       </tr>
     </thead>
     <tbody>
       <tr>
         <td>リーダブルコード</td>
         <td>より良いコードを書くためのシンプルで実践的なテクニック</td>
         <td>
           <a class="show_1995" href="book..">Show</a>
         </td>
         <td>
           <a class="edit_1995" href="books/..">Edit</a>
         </td>
         <td>
           <a data-confirm= class>Destroy</a>
         </td>
        </tr>
        <tr>
         <td>トラブル知らずのシステム設計</td>
         <td>システム設計の要点を図解で説明してくれます</td>
         <td>
           <a class="show_1995" href="book..">Show</a>
         </td>
         <td>
           <a class="edit_1995" href="books/..">Edit</a>
         </td>
         <td>
           <a data-confirm= class>Destroy</a>
         </td>
        </tr>
        <tr>
         <td>たのしいRuby</td>
         <td>Rubyの入門におすすめです</td>
         <td>
           <a class="show_1995" href="book..">Show</a>
         </td>
         <td>
           <a class="edit_1995" href="books/..">Edit</a>
         </td>
         <td>
           <a data-confirm= class>Destroy</a>
         </td>
        </tr>
        <tr>
         <td>入門Git</td>
         <td>gitについての基本操作から内部構造まで解説してくれます</td>
         <td>
           <a class="show_1995" href="book..">Show</a>
         </td>
         <td>
           <a class="edit_1995" href="books/..">Edit</a>
         </td>
         <td>
           <a data-confirm= class>Destroy</a>
         </td>
        </tr>
        <tr>
         <td>アルゴリズム図鑑</td>
         <td>アルゴリズムについてカラーイラストでしっかり解説してくれます</td>
         <td>
           <a class="show_1995" href="book..">Show</a>
         </td>
         <td>
           <a class="edit_1995" href="books/..">Edit</a>
         </td>
         <td>
           <a data-confirm= class>Destroy</a>
         </td>
        </tr>
        <tr>
         <td>達人プログラマー</td>
         <td>プログラマ入門者は必読！</td>
         <td>
           <a class="show_1995" href="book..">Show</a>
         </td>
         <td>
           <a class="edit_1995" href="books/..">Edit</a>
         </td>
         <td>
           <a data-confirm= class>Destroy</a>
         </td>
        </tr>
        <tr>
         <td>データベース実践入門</td>
         <td>効率的なSQL文を教えてくれます</td>
         <td>
           <a class="show_1995" href="book..">Show</a>
         </td>
         <td>
           <a class="edit_1995" href="books/..">Edit</a>
         </td>
         <td>
           <a data-confirm= class>Destroy</a>
         </td>
        </tr>
     </tbody>
   </table>
   <h2>New book</h2>
   <from class="new_book" id= action= accept= mehod= >
    <input name="utf8" type="hidden" value="✓">
    <input type="hidden" name="authenticity_token" value="FQd8D9WQW5YVLQjZ1HNdaZnb177jMqn8w2DHMIBVOg2xjdeUmSvYIyblUoxTmRkz9tLUOLwfH7aQ6kKSNHmZnw==">
    <div class="field">
    <label for="book_title">Title</label>
    <input class="book_title" type="text" name="book[title]" id="book_title">
    </div>
    <div class="field">
    <label for="book_body">Body</label>
    <textarea class="book_body" name="book[body]" id="book_body"></textarea>
    </div>
    <div class="actions">
    <input type="submit" name="commit" value="Create Book" data-disable-with="Create Book">
    </div>
   </from>
</body>
</html>





<%= form_with model: @Books, url: '/lists', method: :post do |f| %>

<% @books.each do |list| %>





